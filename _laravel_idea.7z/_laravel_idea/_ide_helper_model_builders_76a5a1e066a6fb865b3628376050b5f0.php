<?php //7bb758510439cf0352e20769e0f38125
/** @noinspection all */

namespace LaravelIdea\Helper\App\Models {

    use App\Models\Test;
    use App\Models\User;
    use Illuminate\Contracts\Database\Query\Expression;
    use Illuminate\Contracts\Support\Arrayable;
    use Illuminate\Pagination\LengthAwarePaginator;
    use Illuminate\Pagination\Paginator;
    use LaravelIdea\Helper\_BaseBuilder;
    use LaravelIdea\Helper\_BaseCollection;

    /**
     * @method Test|null getOrPut($key, \Closure $value)
     * @method Test|$this shift(int $count = 1)
     * @method Test|null firstOrFail(callable|string $key = null, $operator = null, $value = null)
     * @method Test|$this pop(int $count = 1)
     * @method Test|null pull($key, \Closure $default = null)
     * @method Test|null last(callable $callback = null, \Closure $default = null)
     * @method Test|$this random(callable|int|null $number = null, bool $preserveKeys = false)
     * @method Test|null sole(callable|string $key = null, $operator = null, $value = null)
     * @method Test|null get($key, \Closure $default = null)
     * @method Test|null first(callable $callback = null, \Closure $default = null)
     * @method Test|null firstWhere(callable|string $key, $operator = null, $value = null)
     * @method Test|null find($key, $default = null)
     * @method Test[] all()
     */
    class _IH_Test_C extends _BaseCollection {
        /**
         * @param int $size
         * @return Test[][]
         */
        public function chunk($size)
        {
            return [];
        }
    }

    /**
     * @method Test baseSole(array|string $columns = ['*'])
     * @method Test create(array $attributes = [])
     * @method _IH_Test_C|Test[] cursor()
     * @method Test|null|_IH_Test_C|Test[] find($id, array|string $columns = ['*'])
     * @method _IH_Test_C|Test[] findMany(array|Arrayable $ids, array|string $columns = ['*'])
     * @method Test|_IH_Test_C|Test[] findOr($id, array|\Closure|string $columns = ['*'], \Closure $callback = null)
     * @method Test|_IH_Test_C|Test[] findOrFail($id, array|string $columns = ['*'])
     * @method Test|_IH_Test_C|Test[] findOrNew($id, array|string $columns = ['*'])
     * @method Test first(array|string $columns = ['*'])
     * @method Test firstOr(array|\Closure|string $columns = ['*'], \Closure $callback = null)
     * @method Test firstOrCreate(array $attributes = [], array $values = [])
     * @method Test firstOrFail(array|string $columns = ['*'])
     * @method Test firstOrNew(array $attributes = [], array $values = [])
     * @method Test firstWhere(array|\Closure|Expression|string $column, $operator = null, $value = null, string $boolean = 'and')
     * @method Test forceCreate(array $attributes)
     * @method Test forceCreateQuietly(array $attributes = [])
     * @method _IH_Test_C|Test[] fromQuery(string $query, array $bindings = [])
     * @method _IH_Test_C|Test[] get(array|string $columns = ['*'])
     * @method Test getModel()
     * @method Test[] getModels(array|string $columns = ['*'])
     * @method _IH_Test_C|Test[] hydrate(array $items)
     * @method Test make(array $attributes = [])
     * @method Test newModelInstance(array $attributes = [])
     * @method LengthAwarePaginator|Test[]|_IH_Test_C paginate(\Closure|int|null $perPage = null, array|string $columns = ['*'], string $pageName = 'page', int|null $page = null)
     * @method Paginator|Test[]|_IH_Test_C simplePaginate(int|null $perPage = null, array|string $columns = ['*'], string $pageName = 'page', int|null $page = null)
     * @method Test sole(array|string $columns = ['*'])
     * @method Test updateOrCreate(array $attributes, array $values = [])
     */
    class _IH_Test_QB extends _BaseBuilder {}

    /**
     * @method User|null getOrPut($key, \Closure $value)
     * @method User|$this shift(int $count = 1)
     * @method User|null firstOrFail(callable|string $key = null, $operator = null, $value = null)
     * @method User|$this pop(int $count = 1)
     * @method User|null pull($key, \Closure $default = null)
     * @method User|null last(callable $callback = null, \Closure $default = null)
     * @method User|$this random(callable|int|null $number = null, bool $preserveKeys = false)
     * @method User|null sole(callable|string $key = null, $operator = null, $value = null)
     * @method User|null get($key, \Closure $default = null)
     * @method User|null first(callable $callback = null, \Closure $default = null)
     * @method User|null firstWhere(callable|string $key, $operator = null, $value = null)
     * @method User|null find($key, $default = null)
     * @method User[] all()
     */
    class _IH_User_C extends _BaseCollection {
        /**
         * @param int $size
         * @return User[][]
         */
        public function chunk($size)
        {
            return [];
        }
    }

    /**
     * @method _IH_User_QB whereId($value)
     * @method _IH_User_QB whereName($value)
     * @method _IH_User_QB whereEmail($value)
     * @method _IH_User_QB whereEmailVerifiedAt($value)
     * @method _IH_User_QB wherePassword($value)
     * @method _IH_User_QB whereRememberToken($value)
     * @method _IH_User_QB whereCreatedAt($value)
     * @method _IH_User_QB whereUpdatedAt($value)
     * @method User baseSole(array|string $columns = ['*'])
     * @method User create(array $attributes = [])
     * @method _IH_User_C|User[] cursor()
     * @method User|null|_IH_User_C|User[] find($id, array|string $columns = ['*'])
     * @method _IH_User_C|User[] findMany(array|Arrayable $ids, array|string $columns = ['*'])
     * @method User|_IH_User_C|User[] findOr($id, array|\Closure|string $columns = ['*'], \Closure $callback = null)
     * @method User|_IH_User_C|User[] findOrFail($id, array|string $columns = ['*'])
     * @method User|_IH_User_C|User[] findOrNew($id, array|string $columns = ['*'])
     * @method User first(array|string $columns = ['*'])
     * @method User firstOr(array|\Closure|string $columns = ['*'], \Closure $callback = null)
     * @method User firstOrCreate(array $attributes = [], array $values = [])
     * @method User firstOrFail(array|string $columns = ['*'])
     * @method User firstOrNew(array $attributes = [], array $values = [])
     * @method User firstWhere(array|\Closure|Expression|string $column, $operator = null, $value = null, string $boolean = 'and')
     * @method User forceCreate(array $attributes)
     * @method User forceCreateQuietly(array $attributes = [])
     * @method _IH_User_C|User[] fromQuery(string $query, array $bindings = [])
     * @method _IH_User_C|User[] get(array|string $columns = ['*'])
     * @method User getModel()
     * @method User[] getModels(array|string $columns = ['*'])
     * @method _IH_User_C|User[] hydrate(array $items)
     * @method User make(array $attributes = [])
     * @method User newModelInstance(array $attributes = [])
     * @method LengthAwarePaginator|User[]|_IH_User_C paginate(\Closure|int|null $perPage = null, array|string $columns = ['*'], string $pageName = 'page', int|null $page = null)
     * @method Paginator|User[]|_IH_User_C simplePaginate(int|null $perPage = null, array|string $columns = ['*'], string $pageName = 'page', int|null $page = null)
     * @method User sole(array|string $columns = ['*'])
     * @method User updateOrCreate(array $attributes, array $values = [])
     */
    class _IH_User_QB extends _BaseBuilder {}
}
